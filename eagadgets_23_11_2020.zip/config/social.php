<?php

return [
    'whatsapp_number'=>'+258844480823',
    'phone_number' => '258844480823',
    'pixel' => '3663972583662029',
    'app_domain' => 'eagadgets.com',
    ];
    