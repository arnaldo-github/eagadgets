<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProdutcController extends Controller
{
    //
}
